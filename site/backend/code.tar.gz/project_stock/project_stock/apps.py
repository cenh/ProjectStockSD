from django.apps import AppConfig


class ProjectStockConfig(AppConfig):
    name = 'project_stock'
